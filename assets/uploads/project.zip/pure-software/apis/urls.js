module.exports = {
  getResultURL: `https://evening-brook-34199.herokuapp.com/application`,
};
